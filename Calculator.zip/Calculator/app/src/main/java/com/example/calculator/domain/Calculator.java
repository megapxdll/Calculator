package com.example.calculator.domain;

public interface Calculator {

    double performOperation(double argOne, double argTwo, Operation operation);
}
