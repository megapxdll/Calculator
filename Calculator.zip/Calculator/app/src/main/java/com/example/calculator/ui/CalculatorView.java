package com.example.calculator.ui;

public interface CalculatorView {
    void showResult(String result);
}
