package com.example.calculator.domain;

public enum Operation {
    ADD,
    SUB,
    DIV,
    MULT
}
